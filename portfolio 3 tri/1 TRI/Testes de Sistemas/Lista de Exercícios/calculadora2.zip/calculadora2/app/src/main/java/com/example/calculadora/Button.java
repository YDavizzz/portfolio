package com.example.calculadora;public class Button {
    public void setOnClickListener(Object o) {
    }
}
