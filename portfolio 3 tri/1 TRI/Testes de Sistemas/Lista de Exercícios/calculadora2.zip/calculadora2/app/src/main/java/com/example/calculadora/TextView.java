package com.example.calculadora;

public class TextView {
    public void setText(String valueOf) {
    }
}
